using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

[System.Serializable, VolumeComponentMenuForRenderPipeline("JJ/UETonemapping",typeof(UniversalRenderPipeline))]
public class UETonemappingSettings : VolumeComponent, IPostProcessComponent
{
    [Tooltip("UE 的Tonemapping ACES")]
    public BoolParameter enable = new BoolParameter(true);
    public ClampedFloatParameter FilmSlope = new ClampedFloatParameter(0.88f, 0, 1, false);
    public ClampedFloatParameter FilmToe = new ClampedFloatParameter(0.55f, 0, 1, false);
    public ClampedFloatParameter FilmShoulder = new ClampedFloatParameter(0.26f, 0, 1, false);
    public ClampedFloatParameter FilmBlackClip = new ClampedFloatParameter(0f, 0, 1, false);
    public ClampedFloatParameter FilmWhiteClip = new ClampedFloatParameter(0.035f, 0, 1, false);
    
    
    //接口的实现
    public bool IsActive()
    {
        return enable.value;
        // return (DistortionStrength.value > 0.0f) && active;
    }

    public bool IsTileCompatible()
    {
        return false;
    }
}
