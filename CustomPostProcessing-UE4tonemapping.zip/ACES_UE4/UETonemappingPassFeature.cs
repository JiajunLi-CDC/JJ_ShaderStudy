using UnityEditor.Rendering;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class UETonemappingPassFeature : ScriptableRendererFeature
{
    UETonemappingPass m_ScriptablePass;
    public override void Create()
    {
        // m_ScriptablePass = new CustomRenderPass(settings.material);
        m_ScriptablePass = new UETonemappingPass(RenderPassEvent.BeforeRenderingPostProcessing);
    }
    
    public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
    {
        // m_ScriptablePass.source = renderer.cameraColorTarget;
        renderer.EnqueuePass(m_ScriptablePass);
    }
    
    class UETonemappingPass : ScriptableRenderPass
    {
        // 用于Shader中使用的Uniform变量
        static class ShaderIDs
        {
            internal static readonly int FilmSlope = Shader.PropertyToID("_FilmSlope");
            internal static readonly int FilmToe = Shader.PropertyToID("_FilmToe");
            internal static readonly int FilmShoulder = Shader.PropertyToID("_FilmShoulder");
            internal static readonly int FilmBlackClip = Shader.PropertyToID("_FilmBlackClip");
            internal static readonly int FilmWhiteClip = Shader.PropertyToID("_FilmWhiteClip");
        }
        
        // 用于FrameDebugger或其他Profiler中显示的名字
        private const string m_ProfilerTag = "UETonemapping Block";
        // 后处理配置类
        private UETonemappingSettings volumeStack;
        
        public UETonemappingPass(RenderPassEvent evt)
        {
            renderPassEvent = evt;
        }
        
        //pass的内容
        public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
        {
            // 获取后处理配置
            var volumeStack = VolumeManager.instance.stack;  //获取volumn堆栈
            var UE4_TonemappingData = volumeStack.GetComponent<UETonemappingSettings>();

            CommandBuffer cmd = CommandBufferPool.Get(m_ProfilerTag);
            // 当效果激活时才执行逻辑
            bool active = UE4_TonemappingData.IsActive();
            if (active)
            {
                cmd.SetGlobalFloat(ShaderIDs.FilmSlope, UE4_TonemappingData.FilmSlope.value);
                cmd.SetGlobalFloat(ShaderIDs.FilmToe, UE4_TonemappingData.FilmToe.value);
                cmd.SetGlobalFloat(ShaderIDs.FilmShoulder, UE4_TonemappingData.FilmShoulder.value);
                cmd.SetGlobalFloat(ShaderIDs.FilmBlackClip, UE4_TonemappingData.FilmBlackClip.value);
                cmd.SetGlobalFloat(ShaderIDs.FilmWhiteClip, UE4_TonemappingData.FilmWhiteClip.value);

                // 开启故障宏
                cmd.EnableShaderKeyword("_TONEMAP_ACES_UE4");
            }
            else
            {
                // 关闭故障宏
                cmd.DisableShaderKeyword("_TONEMAP_ACES_UE4");
            }
            context.ExecuteCommandBuffer(cmd);
            CommandBufferPool.Release(cmd);
        }
      

       
    }
}


