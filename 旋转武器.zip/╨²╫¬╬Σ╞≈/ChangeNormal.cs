using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[ExecuteAlways]
public class ChangeNormal : MonoBehaviour
{
    // private Transform targetObject; // 物体的 Transform 组件
    //这里将平滑的法线储存到了tangent中
    Mesh MeshNormalChange(Mesh mesh)
    {
        Matrix4x4 localToWorld = transform.localToWorldMatrix;
        Matrix4x4 localToWorldInverseTranspose = localToWorld.inverse.transpose;
        
        Vector4[] normals = mesh.tangents;
        
        for (int i = 0; i < mesh.vertexCount; ++i)
        {
            Vector3 vecEnd = mesh.vertices[i];

           
            Vector3 VecstartLocal = new Vector3(0, 0, vecEnd.z);
            
            // 将物体的局部坐标转换为世界坐标
            Vector3 vertexWorld = localToWorld.MultiplyPoint(mesh.vertices[i]);
            Vector3 VecstartWorld = localToWorld.MultiplyPoint(VecstartLocal);
            
            Vector3 normalWorld = Vector3.Normalize(vertexWorld - VecstartWorld);
            Vector3 normal = localToWorldInverseTranspose.MultiplyVector(normalWorld);

            normals[i] = new Vector4(normal.x,normal.y,normal.z,0);
        }
        mesh.tangents = normals;
        return mesh;
    }
    void Awake()
    {
        if (GetComponent<MeshFilter>())
        {
            Mesh tempMesh = (Mesh)Instantiate(GetComponent<MeshFilter>().sharedMesh);
            tempMesh=MeshNormalChange(tempMesh);
            gameObject.GetComponent<MeshFilter>().sharedMesh = tempMesh;
        }
        
        if (GetComponent<SkinnedMeshRenderer>())
        {
            Mesh tempMesh = (Mesh)Instantiate(GetComponent<SkinnedMeshRenderer>().sharedMesh);
            tempMesh = MeshNormalChange(tempMesh);
            gameObject.GetComponent<SkinnedMeshRenderer>().sharedMesh = tempMesh;
        }
    }

    private void OnDrawGizmos()
    {
        // Mesh mesh = (Mesh)Instantiate(GetComponent<MeshFilter>().sharedMesh);
        //
        // Matrix4x4 localToWorld = transform.localToWorldMatrix;
        // Matrix4x4 localToWorldInverseTranspose = localToWorld.inverse.transpose;
        //
        // Vector3[] normals = mesh.normals;
        // for (int i = 0; i < mesh.vertexCount; ++i)
        // {
        //     Vector3 vecEnd = mesh.vertices[i];
        //     Vector3 VecstartLocal = new Vector3(0, 0, vecEnd.z);;
        //     
        //     // 将物体的局部坐标转换为世界坐标
        //
        //     Vector3 vertexWorld = localToWorld.MultiplyPoint(mesh.vertices[i]);
        //     Vector3 VecstartWorld = localToWorld.MultiplyPoint(VecstartLocal);
        //     
        //     Vector3 normalWorld = Vector3.Normalize(vertexWorld - VecstartWorld);
        //     
        //     // Gizmos.DrawLine( vertexWorld, vertexWorld+normalWorld);
        //     
        //     // Vector3 vertexData = vertexMatrix.MultiplyPoint (vertices[i]);
        //     Vector3 normal = localToWorldInverseTranspose.MultiplyVector(normalWorld);
        //     Vector3 normalData = localToWorld.MultiplyVector (normal);
        //     normalData.Normalize ();
        //     Gizmos.DrawLine (vertexWorld, vertexWorld + normalData * 0.5f);

           
        // }
    }
}