using System;
using UnityEngine;
using System.Collections.Generic;

[ExecuteAlways]
public class FindVerticesByColor : MonoBehaviour
{
    private List<Vector3> redVerticesPositions = new List<Vector3>();
    private List<Vector3> blueVerticesPositions = new List<Vector3>();

    private int startVertexIndex;
    private int endVertexIndex;

    private Vector3 Rotateaxis;
    
    Matrix4x4 localToWorld;

    // public Material material;

    private Mesh mesh;

    void Start()
    {
      
        // 获取MeshFilter组件以访问网格数据
        MeshFilter meshFilter = GetComponent<MeshFilter>();

        if (meshFilter != null)
        {
            // 获取网格对象
            mesh = meshFilter.mesh;

            // 获取顶点数组和顶点色数组
            Vector3[] vertices = mesh.vertices;
            Color[] colors = mesh.colors;

            // 清除旧的顶点位置数据
            redVerticesPositions.Clear();
            blueVerticesPositions.Clear();

            // 遍历顶点色数组
            for (int i = 0; i < colors.Length; i++)
            {
                Debug.Log("r"+colors[i].r+"g"+colors[i].g+"b"+colors[i].b );
                if (colors[i].r > 0.9f && colors[i].b < 0.2f)
                {
                    redVerticesPositions.Add(transform.TransformPoint(vertices[i]));
                    startVertexIndex = i;
                }
                else if (colors[i].b > 0.5f && colors[i].r < 0.6f)
                {
                    blueVerticesPositions.Add(transform.TransformPoint(vertices[i]));
                    endVertexIndex = i;
                }
                
               
            }
        }
        else
        {
            Debug.LogError("没有找到MeshFilter组件");
        }
    }

    private void Update()
    {
        localToWorld = transform.localToWorldMatrix;
        
        Vector3 startVer = mesh.vertices[startVertexIndex];
        Vector3 endVer = mesh.vertices[endVertexIndex];

        Rotateaxis = Vector3.Normalize(endVer - startVer);
        Vector3 RotateaxisWorld = localToWorld.MultiplyVector(Rotateaxis);
        
        // Debug.Log(Rotateaxis);
        // Debug.Log(RotateaxisWorld);
        
        Shader.SetGlobalVector("_RotateAxisWorld",new Vector4(RotateaxisWorld.x,RotateaxisWorld.y,RotateaxisWorld.z,0));
    }

    // 在编辑器中绘制Gizmos
    void OnDrawGizmos()
    {
        // 绘制红色顶点
        Gizmos.color = Color.red;
        foreach (Vector3 pos in redVerticesPositions)
        {
            Gizmos.DrawSphere(pos, 0.1f);
        }

        // 绘制蓝色顶点
        Gizmos.color = Color.blue;
        foreach (Vector3 pos in blueVerticesPositions)
        {
            Gizmos.DrawSphere(pos, 0.1f);
        }
        
        Vector3 startVer = mesh.vertices[startVertexIndex];
        Vector3 endVer = mesh.vertices[endVertexIndex];
        Gizmos.DrawLine(startVer,endVer);
    }
}